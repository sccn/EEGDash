import pint
import numpy as np
import xarray as xr



registry = pint.UnitRegistry()
pint.set_application_registry(registry)


if __name__ == "__main__":
    registry = pint.UnitRegistry()
    pint.set_application_registry(registry)


