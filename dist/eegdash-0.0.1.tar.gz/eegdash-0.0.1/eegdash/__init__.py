from os import path
import sys
print(path.abspath('../eegdash'))
sys.path.append(path.abspath('../eegdash'))
from eegdash import signalstore
from .signalstore_data_utils import *
from .data_utils import *