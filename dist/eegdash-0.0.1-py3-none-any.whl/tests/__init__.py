from os import path
import sys
sys.path.append(path.abspath('../eegdash'))