from os import path
import sys
sys.path.append(path.abspath('../eegdash'))
from .signalstore_data_utils import *
from .data_utils import *
from main import EEGDash